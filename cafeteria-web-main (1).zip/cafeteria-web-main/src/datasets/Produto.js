let produtos = [
  {
    id: '1',
    imagemUrl:
      'https://images.unsplash.com/photo-1532499016263-f2c3e89de9cd?q=80&w=1760&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    titulo: 'Cookie',
    descricao: 'Feito de cacau 100%.',
    valor: '10.0',
  },
  {
    id: '2',
    imagemUrl:
      'https://images.unsplash.com/photo-1624128082323-beb6b8b508db?q=80&w=1965&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    titulo: 'Patel de forno',
    descricao: 'Feito com frango da Bom Todo.',
    valor: '5.0',
  },
  {
    id: '3',
    imagemUrl:
      'https://images.unsplash.com/photo-1525385133512-2f3bdd039054?q=80&w=2570&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D',
    titulo: 'Suco de Laranja',
    descricao: 'Feita com laranjas de colhetas tardias.',
    valor: '2.0',
  },
];

export default produtos;
